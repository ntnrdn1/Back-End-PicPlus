<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PhotographerTestimonial extends Model
{
    use HasFactory;

    protected $table = 'photographertestimonials';
    public $timestamps = false;
}
